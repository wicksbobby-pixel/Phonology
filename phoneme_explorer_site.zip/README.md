# Phoneme Explorer — GA

Static single-file site. Open index.html locally or host on GitHub Pages / Netlify.
